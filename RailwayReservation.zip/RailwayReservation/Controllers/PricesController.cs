﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using RailwayReservation.Filters;
using RailwayReservation.Models;

namespace RailwayReservation.Controllers
{
    [AuthorizeRole("1")]
    public class PricesController : Controller
    {
        private RailwayDBEntities1 db = new RailwayDBEntities1();
        

        // GET: Prices
        public ActionResult Index()
        {

            var prices = db.Prices.Include(p => p.Coach).Include(p => p.Train_info);
            return View(prices.ToList());
        }

        // GET: Prices/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Price price = db.Prices.Find(id);
            if (price == null)
            {
                return HttpNotFound();
            }
            return View(price);
        }

        // GET: Prices/Create
        public ActionResult Create()
        {
            ViewBag.coach_id = new SelectList(db.Coaches, "id", "CoachName");
            ViewBag.train_id = new SelectList(db.Train_info, "id", "Name");
            return View();
        }

        // POST: Prices/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "id,train_id,coach_id,amount")] Price price)
        {
            if (ModelState.IsValid)
            {
                db.Prices.Add(price);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.coach_id = new SelectList(db.Coaches, "id", "CoachName", price.coach_id);
            ViewBag.train_id = new SelectList(db.Train_info, "id", "Name", price.train_id);
            return View(price);
        }

        // GET: Prices/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Price price = db.Prices.Find(id);
            if (price == null)
            {
                return HttpNotFound();
            }
            ViewBag.coach_id = new SelectList(db.Coaches, "id", "CoachName", price.coach_id);
            ViewBag.train_id = new SelectList(db.Train_info, "id", "Name", price.train_id);
            return View(price);
        }

        // POST: Prices/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,train_id,coach_id,amount")] Price price)
        {
            if (ModelState.IsValid)
            {
                db.Entry(price).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.coach_id = new SelectList(db.Coaches, "id", "CoachName", price.coach_id);
            ViewBag.train_id = new SelectList(db.Train_info, "id", "Name", price.train_id);
            return View(price);
        }

        

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
