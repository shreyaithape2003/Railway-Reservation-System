﻿// Controllers for Login and Registration with Role-Based Redirect

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using RailwayReservation.Models;

namespace RailwayReservationSystem.Controllers
{
    public class AccountController : Controller
    {
        private RailwayDBEntities1 db = new RailwayDBEntities1();

        // GET: Account/Register
        public ActionResult Register()
        {
            return View();
        }

        // POST: Account/Register
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(User user)
        {
            if (ModelState.IsValid)
            {
                // Hash password
                using (SHA256 sha256 = SHA256.Create())
                {
                    byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(user.password));
                    StringBuilder builder = new StringBuilder();
                    foreach (var b in bytes)
                    {
                        builder.Append(b.ToString("x2"));
                    }
                    user.password = builder.ToString();
                }

                db.Users.Add(user);
                db.SaveChanges();

                TempData["Message"] = "Registration successful. Please login.";
                return RedirectToAction("Login");
            }
            return View(user);
        }

        public ActionResult AccessDenied()
        {
            return View();
        }


        // GET: Account/Login
        public ActionResult Login()
        {
            return View();
        }

        // POST: Account/Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(string email, string password)
        {
            string hashed = "";
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (var b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                hashed = builder.ToString();
            }

            var user = db.Users.FirstOrDefault(u => u.email == email && u.password == hashed);

            if (user != null)
            {
                Session["UserId"] = user.id;
                Session["Role"] = user.Role;
                Session["FullName"] = user.full_name;

                if (user.Role == 1) // Admin
                {

                    return RedirectToAction("Index", "Train_info");
                }
                else // Normal user
                {
                    return RedirectToAction("Index", "SearchTrain");
                }
            }

            ViewBag.Message = "Invalid credentials.";
            return View();
        }

        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
