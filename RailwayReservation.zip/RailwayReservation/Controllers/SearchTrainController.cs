﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RailwayReservation.Models;

namespace RailwayReservation.Controllers
{
    public class SearchTrainController : Controller
    {
        private RailwayDBEntities1 db = new RailwayDBEntities1();

        // GET: SearchTrain
        public ActionResult Index(string source, string destination)
        {
            if (!string.IsNullOrEmpty(source) && !string.IsNullOrEmpty(destination))
            {
                var trains = db.Train_info.Where(t => t.Source == source && t.Destination == destination).ToList();
                return View(trains);
            }
            return View(new List<Train_info>());
        }
    }
}