﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RailwayReservation.Filters;
using RailwayReservation.Models;

namespace RailwayReservation.Controllers
{
    [AuthorizeRole("2")]
    public class CancellationController : Controller
    {
        
        private RailwayDBEntities1 db = new RailwayDBEntities1();

        public ActionResult Cancel(int id)
        {
            var booking = db.Bookings
                            .Include("Train_info")
                            .Include("Passengers")
                            .FirstOrDefault(b => b.id == id);

            if (booking == null)
            {
                return HttpNotFound();
            }

            // Refund logic: 10% penalty
            decimal? refund = booking.amount_paid - (booking.amount_paid * 0.1m);
            ViewBag.RefundAmount = refund;
            ViewBag.Booking = booking;

            return View();
        }


        [HttpPost]
        public ActionResult ConfirmCancel(int id)
        {
            var booking = db.Bookings
                            .Include("Passengers")
                            .FirstOrDefault(b => b.id == id);

            if (booking == null || booking.travel_date < DateTime.Now.Date)
                return HttpNotFound();

            

            // Mark booking as cancelled instead of deleting
            booking.status = "Cancelled"; // or booking.is_cancelled = true;

            // Log cancellation
            Cancellation cancellation = new Cancellation
            {
                booking_id = booking.id,
                train_id = booking.train_id,
                user_id = booking.user_id,
                cancellation_date = DateTime.Now,
                refund_amount = booking.amount_paid - (booking.amount_paid * 0.1m)
            };

            db.Cancellations.Add(cancellation);
            db.SaveChanges();

            TempData["Message"] = "Booking cancelled. Refund processed.";
            return View("CancelSuccess");

        }


    }
}