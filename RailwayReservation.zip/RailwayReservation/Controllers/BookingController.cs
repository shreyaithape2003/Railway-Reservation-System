﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RailwayReservation.Filters;
using RailwayReservation.Models;

namespace RailwayReservation.Controllers
{
    [AuthorizeRole("2")]
    public class BookingController : Controller
    {
        
        private RailwayDBEntities1 db = new RailwayDBEntities1();

        //[Authorize] // Ensure only logged-in users can access booking
        public ActionResult Book(int trainId)
        {
            var train = db.Train_info.Find(trainId);
            ViewBag.Coaches = new SelectList(db.Coaches, "id", "CoachName");
            ViewBag.Train = train;
            return View();
        }

        [HttpPost]
        //[Authorize]
        public ActionResult Book(int trainId, int coachId, DateTime travelDate, List<Passenger> passengers)
        {
            if (travelDate < DateTime.Now.Date)
            {
                ModelState.AddModelError("travelDate", "Travel date cannot be in the past.");
            }

            if (ModelState.IsValid)
            {
                int userId = (int)Session["UserId"];

                Booking booking = new Booking
{
    user_id = userId,
    train_id = trainId,
    coach_id = coachId,
    travel_date = travelDate,
    amount_paid = 
        (db.Prices.FirstOrDefault(p => p.train_id == trainId && p.coach_id == coachId)?.amount ?? 0)
        * (passengers?.Count ?? 0),
    status = "Booked"
};


                db.Bookings.Add(booking);
                db.SaveChanges();

                if (passengers != null && passengers.Any())
                {
                    foreach (var p in passengers)
                    {
                        p.booking_id = booking.id;
                        db.Passengers.Add(p);
                    }

                    db.SaveChanges();
                }


                TempData["Success"] = "Booking successful!";
                return RedirectToAction("Success");

            }

            ViewBag.Coaches = new SelectList(db.Coaches, "id", "CoachName");
            return View();
        }

        public ActionResult History()
        {
            int userId = (int)Session["UserId"];
            var bookings = db.Bookings.Include("Train_info")
                           .Where(b => b.user_id == userId)
                           .ToList();

            return View(bookings);
        }
        public ActionResult Success()
        {
            return View();
        }

    }
}