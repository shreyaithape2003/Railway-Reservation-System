﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using RailwayReservation.Filters;
using RailwayReservation.Models;

namespace RailwayReservation.Controllers
{
    [AuthorizeRole("1")]
    public class Train_infoController : Controller
    {
        
        private RailwayDBEntities1 db = new RailwayDBEntities1();
        

        // GET: Train_info
        public ActionResult Index()
        {

            return View(db.Train_info.ToList());
        }

        // GET: Train_info/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Train_info train_info = db.Train_info.Find(id);
            if (train_info == null)
            {
                return HttpNotFound();
            }
            return View(train_info);
        }

        // GET: Train_info/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Train_info/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "id,Name,trainNo,Source,Destination,Departure_time,Arrival_time")] Train_info train_info)
        {
            if (ModelState.IsValid)
            {
                db.Train_info.Add(train_info);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(train_info);
        }

        // GET: Train_info/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Train_info train_info = db.Train_info.Find(id);
            if (train_info == null)
            {
                return HttpNotFound();
            }
            return View(train_info);
        }

        // POST: Train_info/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,Name,trainNo,Source,Destination,Departure_time,Arrival_time")] Train_info train_info)
        {
            if (ModelState.IsValid)
            {
                db.Entry(train_info).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(train_info);
        }

        

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
